var selfDispatch=[
['ZSAQ','是'],
['ZSFY','是'],
['ZUNC','是'],
['ZSYA','是'],
['ZBHD','是'],
['ZBYC','是'],
['ZULB','是'],
['ZYQQ','是'],
['ZYJM','是'],
['ZSYW','是'],
['ZSZS','是'],
['ZSJH','是'],
['ZSGS','是'],
['ZLYL','是']
]